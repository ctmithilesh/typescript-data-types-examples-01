let logged_in: boolean = true
let verificationStatus: boolean = false 

console.log(logged_in,verificationStatus)