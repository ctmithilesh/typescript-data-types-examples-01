// adding a string data type 
const country: string = 'India'
console.log(country)
