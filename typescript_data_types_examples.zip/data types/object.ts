let emp_details: object = {
    emp_id:1, // no need to define data type 
    emp_name:'Ajay Singh',
    emp_designation:'Senior Manager',
    emp_location:'Pune'
}
console.log(emp_details)
//console.log(emp_details.emp_location)