const javacriptDevs: Array<string> = ['John','Steve','Vikram']

const phpDevs: Array<string> = ['Sushil','Jatin','Nikita']
const totalDevs: Array<string> = [...javacriptDevs,...phpDevs]

console.log(totalDevs)