const govtData = {
    gov_id:1241432,
    gov_registration_no:7757754,
    gov_secretary_name:'Amit Shukla',
    gov_office_address:'22 street, delhi',
    gov_office_contact:947567457
}
const { gov_office_contact, gov_secretary_name } = govtData

console.log(gov_office_contact)
console.log(gov_secretary_name)


