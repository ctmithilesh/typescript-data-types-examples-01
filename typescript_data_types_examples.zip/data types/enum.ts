// Declare an Enum 
enum Directions{
    Up = "Up",
    Down = "Down",
    Left = "Left",
    Right = "Right"
}

// assign variable from an Enum
let x: Directions = Directions.Down
console.log(Directions)
console.log(Directions.Up)
console.log(x)

// Declare an Enum Countries
enum Countries{
    India = "India",
}
console.log(Countries)