const salesData: Array<number> = [
    423143,
    56456546,
    65756,
    765765,
    254235,
    546,
    7657,
    16116,
    6363
]

const maxSalesValue = Math.max(...salesData)
const minSalesValue = Math.min(...salesData)
console.log(maxSalesValue, minSalesValue)

