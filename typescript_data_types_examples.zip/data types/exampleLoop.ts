const x: Array<string> = [
    'India',
    'Australia',
    'China',
    'Taiwan',
    'Singapore',
    'Japan'
]
for(let i=0;i<=x.length;i++){
    console.log(x[i])
}
