let contact: number = 4364565465
console.log(contact)