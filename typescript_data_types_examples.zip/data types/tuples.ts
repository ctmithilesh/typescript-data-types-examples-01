// Array Example
const numbers: Array<number> = [100,200,300,400]

// Tuple Example 
const empDetails: [string,number,boolean] = ["Vijay Sharma",35435435,false]

console.log(numbers[0])
console.log(empDetails[0])
