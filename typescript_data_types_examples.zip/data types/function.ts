// function without any arguments
function HelloWorld() {

            console.log("Hello World")

}
HelloWorld()
// Function with arguments
function addNum(x: number, y: number) {
       const result = x+y
       console.log(result)
}
addNum(100,200)
